namespace GMFiOS
{
	public enum CurrentPlayPauseReplayIcon : uint
	{
		Play,
		Pause,
		Replay
	}

	public enum GMFPlayerState : uint
	{
		Empty = 0,
		LoadingContent,
		ReadyToPlay,
		Playing,
		Paused,
		Buffering,
		Seeking,
		Finished,
		Error
	}

	public enum GMFPlayerFinishReason : uint
	{
		PlaybackEnded = 0,
		PlaybackError,
		UserExited
	}
}
