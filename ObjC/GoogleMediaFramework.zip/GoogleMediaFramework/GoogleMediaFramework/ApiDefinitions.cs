using System;
using Foundation;
using ObjCRuntime;
using UIKit;

namespace GMFiOS
{
	// @protocol GMFPlayerControlsViewDelegate <NSObject>
	[Protocol, Model]
	[BaseType (typeof(NSObject))]
	interface GMFPlayerControlsViewDelegate
	{
		// @required -(void)didPressPlay;
		[Abstract]
		[Export ("didPressPlay")]
		void DidPressPlay ();

		// @required -(void)didPressPause;
		[Abstract]
		[Export ("didPressPause")]
		void DidPressPause ();

		// @required -(void)didPressReplay;
		[Abstract]
		[Export ("didPressReplay")]
		void DidPressReplay ();

		// @required -(void)didPressFullscreen:(BOOL)isFullscreen;
		[Abstract]
		[Export ("didPressFullscreen:")]
		void DidPressFullscreen (bool isFullscreen);

		// @required -(void)didSeekToTime:(NSTimeInterval)time;
		[Abstract]
		[Export ("didSeekToTime:")]
		void DidSeekToTime (double time);

		// @required -(void)didStartScrubbing;
		[Abstract]
		[Export ("didStartScrubbing")]
		void DidStartScrubbing ();

		// @required -(void)didEndScrubbing;
		[Abstract]
		[Export ("didEndScrubbing")]
		void DidEndScrubbing ();
	}

	// @interface GMFPlayerControlsView : UIView
	[BaseType (typeof(UIView))]
	interface GMFPlayerControlsView
	{
		// -(void)setTotalTime:(NSTimeInterval)totalTime;
		[Export ("setTotalTime:")]
		void SetTotalTime (double totalTime);

		// -(void)setDownloadedTime:(NSTimeInterval)downloadedTime;
		[Export ("setDownloadedTime:")]
		void SetDownloadedTime (double downloadedTime);

		// -(void)setMediaTime:(NSTimeInterval)mediaTime;
		[Export ("setMediaTime:")]
		void SetMediaTime (double mediaTime);

		// -(void)updateScrubberAndTime;
		[Export ("updateScrubberAndTime")]
		void UpdateScrubberAndTime ();

		// -(CGFloat)preferredHeight;
		[Export ("preferredHeight")]
		[Verify (MethodToProperty)]
		nfloat PreferredHeight { get; }

		// -(void)setDelegate:(id<GMFPlayerControlsViewDelegate>)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (GMFPlayerControlsViewDelegate @delegate);

		// -(void)setSeekbarTrackColor:(UIColor *)color;
		[Export ("setSeekbarTrackColor:")]
		void SetSeekbarTrackColor (UIColor color);

		// -(void)disableSeekbarInteraction;
		[Export ("disableSeekbarInteraction")]
		void DisableSeekbarInteraction ();

		// -(void)enableSeekbarInteraction;
		[Export ("enableSeekbarInteraction")]
		void EnableSeekbarInteraction ();

		// -(void)applyControlTintColor:(UIColor *)color;
		[Export ("applyControlTintColor:")]
		void ApplyControlTintColor (UIColor color);
	}

	// @protocol GMFPlayerControlsProtocol <NSObject>
	[Protocol, Model]
	[BaseType (typeof(NSObject))]
	interface GMFPlayerControlsProtocol
	{
		[Wrap ("WeakDelegate")]
		[NullAllowed]
		GMFPlayerControlsViewDelegate Delegate { get; set; }

		// @required @property (nonatomic, weak) id<GMFPlayerControlsViewDelegate> _Nullable delegate;
		[NullAllowed, Export ("delegate", ArgumentSemantic.Weak)]
		NSObject WeakDelegate { get; set; }

		// @required -(void)showPlayButton;
		[Abstract]
		[Export ("showPlayButton")]
		void ShowPlayButton ();

		// @required -(void)showPauseButton;
		[Abstract]
		[Export ("showPauseButton")]
		void ShowPauseButton ();

		// @required -(void)showReplayButton;
		[Abstract]
		[Export ("showReplayButton")]
		void ShowReplayButton ();

		// @required -(void)enableSeekbarInteraction;
		[Abstract]
		[Export ("enableSeekbarInteraction")]
		void EnableSeekbarInteraction ();

		// @required -(void)disableSeekbarInteraction;
		[Abstract]
		[Export ("disableSeekbarInteraction")]
		void DisableSeekbarInteraction ();

		// @required -(void)setSeekbarTrackColor:(UIColor *)color;
		[Abstract]
		[Export ("setSeekbarTrackColor:")]
		void SetSeekbarTrackColor (UIColor color);

		// @required -(void)setTotalTime:(NSTimeInterval)totalTime;
		[Abstract]
		[Export ("setTotalTime:")]
		void SetTotalTime (double totalTime);

		// @required -(void)setMediaTime:(NSTimeInterval)mediaTime;
		[Abstract]
		[Export ("setMediaTime:")]
		void SetMediaTime (double mediaTime);

		// @optional -(void)addActionButtonWithImage:(UIImage *)image name:(NSString *)name target:(id)target selector:(SEL)selector;
		[Export ("addActionButtonWithImage:name:target:selector:")]
		void AddActionButtonWithImage (UIImage image, string name, NSObject target, Selector selector);

		// @optional -(void)applyControlTintColor:(UIColor *)color;
		[Export ("applyControlTintColor:")]
		void ApplyControlTintColor (UIColor color);

		// @optional -(void)setVideoTitle:(NSString *)videoTitle;
		[Export ("setVideoTitle:")]
		void SetVideoTitle (string videoTitle);

		// @optional -(void)setLogoImage:(UIImage *)logoImage;
		[Export ("setLogoImage:")]
		void SetLogoImage (UIImage logoImage);
	}

	// @interface GMFTopBarView : UIView
	[BaseType (typeof(UIView))]
	interface GMFTopBarView
	{
		// -(void)setLogoImage:(UIImage *)logoImage;
		[Export ("setLogoImage:")]
		void SetLogoImage (UIImage logoImage);

		// -(void)setVideoTitle:(NSString *)videoTitle;
		[Export ("setVideoTitle:")]
		void SetVideoTitle (string videoTitle);

		// -(void)addActionButtonWithImage:(UIImage *)image name:(NSString *)name target:(id)target selector:(SEL)selector;
		[Export ("addActionButtonWithImage:name:target:selector:")]
		void AddActionButtonWithImage (UIImage image, string name, NSObject target, Selector selector);

		// -(CGFloat)preferredHeight;
		[Export ("preferredHeight")]
		[Verify (MethodToProperty)]
		nfloat PreferredHeight { get; }
	}

	// @interface GMFPlayerOverlayView : UIView <GMFPlayerControlsProtocol>
	[BaseType (typeof(UIView))]
	interface GMFPlayerOverlayView : IGMFPlayerControlsProtocol
	{
		// @property (readonly, nonatomic) GMFPlayerControlsView * playerControlsView;
		[Export ("playerControlsView")]
		GMFPlayerControlsView PlayerControlsView { get; }

		// @property (readonly, nonatomic) GMFTopBarView * topBarView;
		[Export ("topBarView")]
		GMFTopBarView TopBarView { get; }

		// @property (nonatomic, strong) UIColor * playPauseResetButtonBackgroundColor;
		[Export ("playPauseResetButtonBackgroundColor", ArgumentSemantic.Strong)]
		UIColor PlayPauseResetButtonBackgroundColor { get; set; }

		[Wrap ("WeakDelegate")]
		[NullAllowed]
		GMFPlayerControlsViewDelegate Delegate { get; set; }

		// @property (nonatomic, weak) id<GMFPlayerControlsViewDelegate> _Nullable delegate;
		[NullAllowed, Export ("delegate", ArgumentSemantic.Weak)]
		NSObject WeakDelegate { get; set; }

		// -(void)showSpinner;
		[Export ("showSpinner")]
		void ShowSpinner ();

		// -(void)hideSpinner;
		[Export ("hideSpinner")]
		void HideSpinner ();

		// -(void)setPlayerBarVisible:(BOOL)visible;
		[Export ("setPlayerBarVisible:")]
		void SetPlayerBarVisible (bool visible);

		// -(void)setSeekbarTrackColor:(UIColor *)color;
		[Export ("setSeekbarTrackColor:")]
		void SetSeekbarTrackColor (UIColor color);

		// -(void)setSeekbarTrackColorDefault;
		[Export ("setSeekbarTrackColorDefault")]
		void SetSeekbarTrackColorDefault ();

		// -(void)addActionButtonWithImage:(UIImage *)image name:(NSString *)name target:(id)target selector:(SEL)selector;
		[Export ("addActionButtonWithImage:name:target:selector:")]
		void AddActionButtonWithImage (UIImage image, string name, NSObject target, Selector selector);

		// -(void)applyControlTintColor:(UIColor *)color;
		[Export ("applyControlTintColor:")]
		void ApplyControlTintColor (UIColor color);

		// -(void)setVideoTitle:(NSString *)videoTitle;
		[Export ("setVideoTitle:")]
		void SetVideoTitle (string videoTitle);

		// -(void)setLogoImage:(UIImage *)logoImage;
		[Export ("setLogoImage:")]
		void SetLogoImage (UIImage logoImage);

		// -(void)disableTopBar;
		[Export ("disableTopBar")]
		void DisableTopBar ();

		// -(void)enableTopBar;
		[Export ("enableTopBar")]
		void EnableTopBar ();
	}

	// @interface GMFPlayerView : UIView
	[BaseType (typeof(UIView))]
	interface GMFPlayerView
	{
		// @property (nonatomic, weak) UIView * _Nullable aboveRenderingView;
		[NullAllowed, Export ("aboveRenderingView", ArgumentSemantic.Weak)]
		UIView AboveRenderingView { get; set; }

		// @property (nonatomic, strong) UIView * renderingView;
		[Export ("renderingView", ArgumentSemantic.Strong)]
		UIView RenderingView { get; set; }

		// @property (readonly, nonatomic) UIView * gestureCapturingView;
		[Export ("gestureCapturingView")]
		UIView GestureCapturingView { get; }

		// -(void)reset;
		[Export ("reset")]
		void Reset ();

		// -(void)setVideoRenderingView:(UIView *)renderingView;
		[Export ("setVideoRenderingView:")]
		void SetVideoRenderingView (UIView renderingView);

		// -(void)setOverlayView:(UIView<GMFPlayerControlsProtocol> *)overlayView;
		[Export ("setOverlayView:")]
		void SetOverlayView (GMFPlayerControlsProtocol overlayView);
	}

	// @protocol GMFVideoPlayerDelegate <NSObject>
	[Protocol, Model]
	[BaseType (typeof(NSObject))]
	interface GMFVideoPlayerDelegate
	{
		// @required -(void)videoPlayer:(GMFVideoPlayer *)videoPlayer stateDidChangeFrom:(GMFPlayerState)fromState to:(GMFPlayerState)toState;
		[Abstract]
		[Export ("videoPlayer:stateDidChangeFrom:to:")]
		void StateDidChangeFrom (GMFVideoPlayer videoPlayer, GMFPlayerState fromState, GMFPlayerState toState);

		// @required -(void)videoPlayer:(GMFVideoPlayer *)videoPlayer currentMediaTimeDidChangeToTime:(NSTimeInterval)time;
		[Abstract]
		[Export ("videoPlayer:currentMediaTimeDidChangeToTime:")]
		void CurrentMediaTimeDidChangeToTime (GMFVideoPlayer videoPlayer, double time);

		// @required -(void)videoPlayer:(GMFVideoPlayer *)videoPlayer currentTotalTimeDidChangeToTime:(NSTimeInterval)time;
		[Abstract]
		[Export ("videoPlayer:currentTotalTimeDidChangeToTime:")]
		void CurrentTotalTimeDidChangeToTime (GMFVideoPlayer videoPlayer, double time);

		// @optional -(void)videoPlayer:(GMFVideoPlayer *)videoPlayer bufferedMediaTimeDidChangeToTime:(NSTimeInterval)time;
		[Export ("videoPlayer:bufferedMediaTimeDidChangeToTime:")]
		void BufferedMediaTimeDidChangeToTime (GMFVideoPlayer videoPlayer, double time);
	}

	// @interface GMFVideoPlayer : NSObject
	[BaseType (typeof(NSObject))]
	interface GMFVideoPlayer
	{
		[Wrap ("WeakDelegate")]
		[NullAllowed]
		GMFVideoPlayerDelegate Delegate { get; set; }

		// @property (nonatomic, weak) id<GMFVideoPlayerDelegate> _Nullable delegate;
		[NullAllowed, Export ("delegate", ArgumentSemantic.Weak)]
		NSObject WeakDelegate { get; set; }

		// @property (readonly, nonatomic) GMFPlayerState state;
		[Export ("state")]
		GMFPlayerState State { get; }

		// @property (readonly, nonatomic) UIView * renderingView;
		[Export ("renderingView")]
		UIView RenderingView { get; }

		// -(void)loadStreamWithURL:(NSURL *)url;
		[Export ("loadStreamWithURL:")]
		void LoadStreamWithURL (NSUrl url);

		// -(void)reset;
		[Export ("reset")]
		void Reset ();

		// -(void)play;
		[Export ("play")]
		void Play ();

		// -(void)pause;
		[Export ("pause")]
		void Pause ();

		// -(void)replay;
		[Export ("replay")]
		void Replay ();

		// -(void)seekToTime:(NSTimeInterval)time;
		[Export ("seekToTime:")]
		void SeekToTime (double time);

		// -(NSTimeInterval)currentMediaTime;
		[Export ("currentMediaTime")]
		[Verify (MethodToProperty)]
		double CurrentMediaTime { get; }

		// -(NSTimeInterval)totalMediaTime;
		[Export ("totalMediaTime")]
		[Verify (MethodToProperty)]
		double TotalMediaTime { get; }

		// -(NSTimeInterval)bufferedMediaTime;
		[Export ("bufferedMediaTime")]
		[Verify (MethodToProperty)]
		double BufferedMediaTime { get; }
	}

	// @protocol GMFPlayerOverlayViewControllerDelegate <GMFPlayerControlsViewDelegate>
	[Protocol, Model]
	interface GMFPlayerOverlayViewControllerDelegate : IGMFPlayerControlsViewDelegate
	{
		// @optional -(void)playerControlsWillShow;
		[Export ("playerControlsWillShow")]
		void PlayerControlsWillShow ();

		// @optional -(void)playerControlsDidShow;
		[Export ("playerControlsDidShow")]
		void PlayerControlsDidShow ();

		// @optional -(void)playerControlsWillHide;
		[Export ("playerControlsWillHide")]
		void PlayerControlsWillHide ();

		// @optional -(void)playerControlsDidHide;
		[Export ("playerControlsDidHide")]
		void PlayerControlsDidHide ();
	}

	// @protocol GMFPlayerOverlayViewControllerProtocol <NSObject>
	[Protocol, Model]
	[BaseType (typeof(NSObject))]
	interface GMFPlayerOverlayViewControllerProtocol
	{
		[Wrap ("WeakDelegate")]
		[NullAllowed]
		GMFPlayerOverlayViewControllerDelegate Delegate { get; set; }

		// @required @property (nonatomic, weak) id<GMFPlayerOverlayViewControllerDelegate> _Nullable delegate;
		[NullAllowed, Export ("delegate", ArgumentSemantic.Weak)]
		NSObject WeakDelegate { get; set; }

		// @required @property (nonatomic, strong) UIView<GMFPlayerControlsProtocol> * playerOverlayView;
		[Export ("playerOverlayView", ArgumentSemantic.Strong)]
		GMFPlayerControlsProtocol PlayerOverlayView { get; set; }

		// @required @property (nonatomic) BOOL userScrubbing;
		[Export ("userScrubbing")]
		bool UserScrubbing { get; set; }

		// @required -(void)showPlayerControlsAnimated:(BOOL)animated;
		[Abstract]
		[Export ("showPlayerControlsAnimated:")]
		void ShowPlayerControlsAnimated (bool animated);

		// @required -(void)hidePlayerControlsAnimated:(BOOL)animated;
		[Abstract]
		[Export ("hidePlayerControlsAnimated:")]
		void HidePlayerControlsAnimated (bool animated);

		// @required -(void)setTotalTime:(NSTimeInterval)totalTime;
		[Abstract]
		[Export ("setTotalTime:")]
		void SetTotalTime (double totalTime);

		// @required -(void)setMediaTime:(NSTimeInterval)mediaTime;
		[Abstract]
		[Export ("setMediaTime:")]
		void SetMediaTime (double mediaTime);

		// @required -(void)togglePlayerControlsVisibility;
		[Abstract]
		[Export ("togglePlayerControlsVisibility")]
		void TogglePlayerControlsVisibility ();

		// @required -(void)playerStateDidChangeToState:(GMFPlayerState)toState;
		[Abstract]
		[Export ("playerStateDidChangeToState:")]
		void PlayerStateDidChangeToState (GMFPlayerState toState);

		// @required -(void)reset;
		[Abstract]
		[Export ("reset")]
		void Reset ();
	}

	// @interface GMFPlayerOverlayViewController : UIViewController <GMFPlayerOverlayViewControllerProtocol>
	[BaseType (typeof(UIViewController))]
	interface GMFPlayerOverlayViewController : IGMFPlayerOverlayViewControllerProtocol
	{
		[Wrap ("WeakDelegate")]
		[NullAllowed]
		GMFPlayerOverlayViewControllerDelegate Delegate { get; set; }

		// @property (nonatomic, weak) id<GMFPlayerOverlayViewControllerDelegate> _Nullable delegate;
		[NullAllowed, Export ("delegate", ArgumentSemantic.Weak)]
		NSObject WeakDelegate { get; set; }

		// @property (nonatomic, strong) UIView<GMFPlayerControlsProtocol> * playerOverlayView;
		[Export ("playerOverlayView", ArgumentSemantic.Strong)]
		GMFPlayerControlsProtocol PlayerOverlayView { get; set; }

		// @property (nonatomic) BOOL userScrubbing;
		[Export ("userScrubbing")]
		bool UserScrubbing { get; set; }

		[Wrap ("WeakVideoPlayerOverlayViewControllerDelegate")]
		[NullAllowed]
		GMFPlayerOverlayViewControllerDelegate VideoPlayerOverlayViewControllerDelegate { get; set; }

		// @property (nonatomic, weak) id<GMFPlayerOverlayViewControllerDelegate> _Nullable videoPlayerOverlayViewControllerDelegate;
		[NullAllowed, Export ("videoPlayerOverlayViewControllerDelegate", ArgumentSemantic.Weak)]
		NSObject WeakVideoPlayerOverlayViewControllerDelegate { get; set; }

		// @property (nonatomic) BOOL isAdDisplayed;
		[Export ("isAdDisplayed")]
		bool IsAdDisplayed { get; set; }

		// -(void)playerStateDidChangeToState:(GMFPlayerState)toState;
		[Export ("playerStateDidChangeToState:")]
		void PlayerStateDidChangeToState (GMFPlayerState toState);

		// -(void)playerControlsDidHide;
		[Export ("playerControlsDidHide")]
		void PlayerControlsDidHide ();

		// -(void)playerControlsWillHide;
		[Export ("playerControlsWillHide")]
		void PlayerControlsWillHide ();

		// -(void)playerControlsDidShow;
		[Export ("playerControlsDidShow")]
		void PlayerControlsDidShow ();

		// -(void)playerControlsWillShow;
		[Export ("playerControlsWillShow")]
		void PlayerControlsWillShow ();

		// -(GMFPlayerControlsView *)playerControlsView;
		[Export ("playerControlsView")]
		[Verify (MethodToProperty)]
		GMFPlayerControlsView PlayerControlsView { get; }

		// -(void)resetAutoHideTimer;
		[Export ("resetAutoHideTimer")]
		void ResetAutoHideTimer ();
	}

	[Static]
	[Verify (ConstantsInterfaceAssociation)]
	partial interface Constants
	{
		// extern NSString *const kGMFPlayerCurrentMediaTimeDidChangeNotification;
		[Field ("kGMFPlayerCurrentMediaTimeDidChangeNotification", "__Internal")]
		NSString kGMFPlayerCurrentMediaTimeDidChangeNotification { get; }

		// extern NSString *const kGMFPlayerCurrentTotalTimeDidChangeNotification;
		[Field ("kGMFPlayerCurrentTotalTimeDidChangeNotification", "__Internal")]
		NSString kGMFPlayerCurrentTotalTimeDidChangeNotification { get; }

		// extern NSString *const kGMFPlayerDidMinimizeNotification;
		[Field ("kGMFPlayerDidMinimizeNotification", "__Internal")]
		NSString kGMFPlayerDidMinimizeNotification { get; }

		// extern NSString *const kGMFPlayerPlaybackStateDidChangeNotification;
		[Field ("kGMFPlayerPlaybackStateDidChangeNotification", "__Internal")]
		NSString kGMFPlayerPlaybackStateDidChangeNotification { get; }

		// extern NSString *const kGMFPlayerStateDidChangeToFinishedNotification;
		[Field ("kGMFPlayerStateDidChangeToFinishedNotification", "__Internal")]
		NSString kGMFPlayerStateDidChangeToFinishedNotification { get; }

		// extern NSString *const kGMFPlayerStateWillChangeToFinishedNotification;
		[Field ("kGMFPlayerStateWillChangeToFinishedNotification", "__Internal")]
		NSString kGMFPlayerStateWillChangeToFinishedNotification { get; }

		// extern NSString *const kGMFPlayerPlaybackDidFinishReasonUserInfoKey;
		[Field ("kGMFPlayerPlaybackDidFinishReasonUserInfoKey", "__Internal")]
		NSString kGMFPlayerPlaybackDidFinishReasonUserInfoKey { get; }

		// extern NSString *const kGMFPlayerPlaybackWillFinishReasonUserInfoKey;
		[Field ("kGMFPlayerPlaybackWillFinishReasonUserInfoKey", "__Internal")]
		NSString kGMFPlayerPlaybackWillFinishReasonUserInfoKey { get; }
	}

	// @interface GMFPlayerViewController : UIViewController <GMFVideoPlayerDelegate, GMFPlayerOverlayViewControllerDelegate, GMFPlayerControlsViewDelegate, UIGestureRecognizerDelegate>
	[BaseType (typeof(UIViewController))]
	interface GMFPlayerViewController : IGMFVideoPlayerDelegate, IGMFPlayerOverlayViewControllerDelegate, IGMFPlayerControlsViewDelegate, IUIGestureRecognizerDelegate
	{
		// @property (readonly, nonatomic) GMFPlayerView * playerView;
		[Export ("playerView")]
		GMFPlayerView PlayerView { get; }

		// @property (nonatomic, strong) UIViewController<GMFPlayerOverlayViewControllerProtocol> * videoPlayerOverlayViewController;
		[Export ("videoPlayerOverlayViewController", ArgumentSemantic.Strong)]
		GMFPlayerOverlayViewControllerProtocol VideoPlayerOverlayViewController { get; set; }

		// @property (nonatomic, weak) GMFAdService * _Nullable adService;
		[NullAllowed, Export ("adService", ArgumentSemantic.Weak)]
		GMFAdService AdService { get; set; }

		// @property (readonly, getter = isVideoFinished, nonatomic) BOOL videoFinished;
		[Export ("videoFinished")]
		bool VideoFinished { [Bind ("isVideoFinished")] get; }

		// @property (nonatomic, strong) UIColor * controlTintColor;
		[Export ("controlTintColor", ArgumentSemantic.Strong)]
		UIColor ControlTintColor { get; set; }

		// @property (nonatomic, strong) NSString * videoTitle;
		[Export ("videoTitle", ArgumentSemantic.Strong)]
		string VideoTitle { get; set; }

		// @property (nonatomic, strong) UIImage * logoImage;
		[Export ("logoImage", ArgumentSemantic.Strong)]
		UIImage LogoImage { get; set; }

		// @property (nonatomic) BOOL isFullscreen;
		[Export ("isFullscreen")]
		bool IsFullscreen { get; set; }

		// -(void)loadStreamWithURL:(NSURL *)URL;
		[Export ("loadStreamWithURL:")]
		void LoadStreamWithURL (NSUrl URL);

		// -(void)play;
		[Export ("play")]
		void Play ();

		// -(void)pause;
		[Export ("pause")]
		void Pause ();

		// -(GMFPlayerState)playbackState;
		[Export ("playbackState")]
		[Verify (MethodToProperty)]
		GMFPlayerState PlaybackState { get; }

		// -(NSTimeInterval)currentMediaTime;
		[Export ("currentMediaTime")]
		[Verify (MethodToProperty)]
		double CurrentMediaTime { get; }

		// -(NSTimeInterval)totalMediaTime;
		[Export ("totalMediaTime")]
		[Verify (MethodToProperty)]
		double TotalMediaTime { get; }

		// -(void)addActionButtonWithImage:(UIImage *)image name:(NSString *)name target:(id)target selector:(SEL)selector;
		[Export ("addActionButtonWithImage:name:target:selector:")]
		void AddActionButtonWithImage (UIImage image, string name, NSObject target, Selector selector);

		// -(void)registerAdService:(GMFAdService *)adService;
		[Export ("registerAdService:")]
		void RegisterAdService (GMFAdService adService);

		// -(void)setAboveRenderingView:(UIView *)view;
		[Export ("setAboveRenderingView:")]
		void SetAboveRenderingView (UIView view);

		// -(void)setControlsVisibility:(BOOL)visible animated:(BOOL)animated;
		[Export ("setControlsVisibility:animated:")]
		void SetControlsVisibility (bool visible, bool animated);

		// -(void)setVideoPlayerOverlayDelegate:(id<GMFPlayerControlsViewDelegate>)delegate;
		[Export ("setVideoPlayerOverlayDelegate:")]
		void SetVideoPlayerOverlayDelegate (GMFPlayerControlsViewDelegate @delegate);

		// -(void)setDefaultVideoPlayerOverlayDelegate;
		[Export ("setDefaultVideoPlayerOverlayDelegate")]
		void SetDefaultVideoPlayerOverlayDelegate ();

		// -(UIView<GMFPlayerControlsProtocol> *)playerOverlayView;
		[Export ("playerOverlayView")]
		[Verify (MethodToProperty)]
		GMFPlayerControlsProtocol PlayerOverlayView { get; }
	}

	// @interface GMFAdService : NSObject
	[BaseType (typeof(NSObject))]
	interface GMFAdService
	{
		// @property (nonatomic, weak) GMFPlayerViewController * _Nullable videoPlayerController;
		[NullAllowed, Export ("videoPlayerController", ArgumentSemantic.Weak)]
		GMFPlayerViewController VideoPlayerController { get; set; }

		// -(id)initWithGMFVideoPlayer:(GMFPlayerViewController *)videoPlayerController;
		[Export ("initWithGMFVideoPlayer:")]
		IntPtr Constructor (GMFPlayerViewController videoPlayerController);
	}

	// @interface GMFResources : NSObject
	[BaseType (typeof(NSObject))]
	interface GMFResources
	{
		// +(UIImage *)playerBarPlayButtonImage;
		[Static]
		[Export ("playerBarPlayButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarPlayButtonImage { get; }

		// +(UIImage *)playerBarPlayLargeButtonImage;
		[Static]
		[Export ("playerBarPlayLargeButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarPlayLargeButtonImage { get; }

		// +(UIImage *)playerBarPauseButtonImage;
		[Static]
		[Export ("playerBarPauseButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarPauseButtonImage { get; }

		// +(UIImage *)playerBarPauseLargeButtonImage;
		[Static]
		[Export ("playerBarPauseLargeButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarPauseLargeButtonImage { get; }

		// +(UIImage *)playerBarReplayButtonImage;
		[Static]
		[Export ("playerBarReplayButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarReplayButtonImage { get; }

		// +(UIImage *)playerBarReplayLargeButtonImage;
		[Static]
		[Export ("playerBarReplayLargeButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarReplayLargeButtonImage { get; }

		// +(UIImage *)playerBarMinimizeButtonImage;
		[Static]
		[Export ("playerBarMinimizeButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarMinimizeButtonImage { get; }

		// +(UIImage *)playerBarMaximizeButtonImage;
		[Static]
		[Export ("playerBarMaximizeButtonImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarMaximizeButtonImage { get; }

		// +(UIImage *)playerBarScrubberThumbImage;
		[Static]
		[Export ("playerBarScrubberThumbImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarScrubberThumbImage { get; }

		// +(UIImage *)playerBarBackgroundImage;
		[Static]
		[Export ("playerBarBackgroundImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerBarBackgroundImage { get; }

		// +(UIImage *)playerTitleBarBackgroundImage;
		[Static]
		[Export ("playerTitleBarBackgroundImage")]
		[Verify (MethodToProperty)]
		UIImage PlayerTitleBarBackgroundImage { get; }
	}

	// @interface GMFTintableButton (UIButton)
	[Category]
	[BaseType (typeof(UIButton))]
	interface UIButton_GMFTintableButton
	{
		// -(void)GMF_applyTintColor:(UIColor *)color;
		[Export ("GMF_applyTintColor:")]
		void GMF_applyTintColor (UIColor color);
	}

	// @interface GMFTintableImage (UIImage)
	[Category]
	[BaseType (typeof(UIImage))]
	interface UIImage_GMFTintableImage
	{
		// -(UIImage *)GMF_createTintedImage:(UIColor *)color;
		[Export ("GMF_createTintedImage:")]
		UIImage GMF_createTintedImage (UIColor color);
	}

	// @interface GMFLabelsAdditions (UILabel)
	[Category]
	[BaseType (typeof(UILabel))]
	interface UILabel_GMFLabelsAdditions
	{
		// +(UILabel *)GMF_clearLabelForPlayerControls;
		[Static]
		[Export ("GMF_clearLabelForPlayerControls")]
		[Verify (MethodToProperty)]
		UILabel GMF_clearLabelForPlayerControls { get; }
	}

	// @interface GMFSlider (UISlider)
	[Category]
	[BaseType (typeof(UISlider))]
	interface UISlider_GMFSlider
	{
	}
}
